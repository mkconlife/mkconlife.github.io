# ��������
Add-Type -AssemblyName System.Windows.Forms
$form = New-Object System.Windows.Forms.Form
$form.Text = ":D?"
$form.StartPosition = "CenterScreen"
$form.Size = New-Object System.Drawing.Size(300,200)

# ������ť
$btnRestoreClose = New-Object System.Windows.Forms.Button
$btnRestoreClose.Location = New-Object System.Drawing.Point(50,50)
$btnRestoreClose.Size = New-Object System.Drawing.Size(100,50)
$btnRestoreClose.Text = "�ָ����ر������"
$btnRestoreClose.Add_Click({
    Start-Process -FilePath "getRecovered.bat"
    $form.Close()
})

$btnRestartProgram = New-Object System.Windows.Forms.Button
$btnRestartProgram.Location = New-Object System.Drawing.Point(150,50)
$btnRestartProgram.Size = New-Object System.Drawing.Size(100,50)
$btnRestartProgram.Text = "��������"
$btnRestartProgram.Add_Click({
    Start-Process -FilePath "getRestart.bat"
    $form.Close()
})

# ����ť���ӵ�����
$form.Controls.Add($btnRestoreClose)
$form.Controls.Add($btnRestartProgram)

# ��ʾ����
$form.ShowDialog()